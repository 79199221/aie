<?php

namespace Ixiaozi\Multi\Controllers;

use Illuminate\Http\Request;

class IndexController extends Controller
{
    public function index(Request $request){
    	dd(__DIR__);
    }
}
