<?php
use Ixiaozi\Multi\Facades\Multi;

Multi::loadRoutes();