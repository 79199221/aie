<?php

namespace Ixiaozi\Multi\Routes;

use Illuminate\Support\Facades\Route;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;

class MultiRoute {
	public function load(){
		require __DIR__ . '/web.php';
	}
}