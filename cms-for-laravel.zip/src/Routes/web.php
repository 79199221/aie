<?php
use Illuminate\Support\Facades\Route;
// Route::middleware('web')->namespace('Ixiaozi\Multi\Controllers')->group([], function(){
//     Route::get('/test', IndexController::class . '@index');
// });

Route::middleware('web')->namespace('Ixiaozi\Multi\Controllers')->group(function(){
	Route::get('/test',  'IndexController@index');
});